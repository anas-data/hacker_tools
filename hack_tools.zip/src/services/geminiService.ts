import { SystemMetrics, InsightData } from "../types";

export async function generateNeuralInsights(
  logs: string[],
  metrics: SystemMetrics
): Promise<InsightData[]> {
  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ logs, metrics }),
    });
    const data = await response.json();
    if (data.success) return data.insights;
    throw new Error();
  } catch (error) {
    return [{
      title: "صمت النواة الخلفية",
      desc: "الخادم الوسيط غير مستجيب. يرجى التحقق من مسارات الشبكة.",
      status: "critical"
    }];
  }
}

export async function generateSpeech(text: string): Promise<string | null> {
  try {
    const response = await fetch("/api/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    const data = await response.json();
    if (data.success) return data.audioBase64;
  } catch (error) {
    console.error("Failed to generate speech via backend:", error);
  }
  return null;
}

export async function sendTerminalMessage(message: string, history: {role: string, text: string}[]): Promise<string> {
  try {
    const response = await fetch("/api/terminal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, history }),
    });
    const data = await response.json();
    if (data.success) return data.text;
    return "خطأ: لم يتم تلقي استجابة حاسمة.";
  } catch (error) {
    return "محطة الأوامر معطلة - الخادم الرئيسي لا يستجيب.";
  }
}
