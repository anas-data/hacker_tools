import { CheckCircle2, RefreshCw } from "lucide-react";
import { InsightItemProps } from "../types";

export function InsightItem({ title, desc, icon, status }: InsightItemProps) {
  return (
    <li className="text-[13px] leading-relaxed pr-4 border-r-2 border-app-gold group relative">
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2 text-app-gold font-medium">
          <span aria-hidden="true">{icon}</span>
          <strong>{title}:</strong>
        </div>
        {status === "checked" && <CheckCircle2 className="w-3 h-3 text-green-500" aria-label="حالة الاستنتاج: نجاح" />}
        {status === "scanning" && <RefreshCw className="w-3 h-3 text-app-gold animate-spin" aria-label="حالة الاستنتاج: قيد الفحص" />}
      </div>
      <div className="text-app-text-dim group-hover:text-app-text transition-colors duration-300">
        {desc}
      </div>
    </li>
  );
}
