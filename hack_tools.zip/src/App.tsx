/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { 
  Header, 
  Footer, 
  MetricsPanel, 
  InsightsPanel, 
  DiagnosticVisualizer, 
  SystemLogs,
  NeuralTerminal,
  SettingsModal
} from "./components";
import { SystemMetrics, InsightData } from "./types";
import { generateNeuralInsights, generateSpeech } from "./services/geminiService";
import { systemAudio } from "./utils/audio";
import { AnimatePresence } from "motion/react";
import { Terminal, Settings2 } from "lucide-react";

export default function App() {
  const [isTesting, setIsTesting] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [testProgress, setTestProgress] = useState(0);
  const [testStage, setTestStage] = useState("");
  const [logs, setLogs] = useState<string[]>([]);
  const [retryCount, setRetryCount] = useState(0);
  const backoffTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const [isTerminalOpen, setIsTerminalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const [metrics, setMetrics] = useState<SystemMetrics>({
    cpu: 98.2,
    patterns: 84.5,
    data: 1.2
  });

  const [insights, setInsights] = useState<InsightData[]>([
    {
      title: "جاهزية النظام",
      desc: "في انتظار بدء دورة التشخيص واختبار النواة العصبية.",
      status: "checked"
    }
  ]);

  const addLog = (msg: string) => {
    setLogs(prev => [msg, ...prev].slice(0, 5));
  };

  const startDiagnostic = (attempt: number) => {
    setIsTesting(true);
    setTestProgress(0);
    setRetryCount(attempt);
    
    // Play start or retry sound
    if (attempt === 0) {
      systemAudio.playStart();
      setTestStage("Initializing Core...");
      setLogs(["[START] Initiating full system diagnostic...", "[INFO] Connecting to Neuralis Archive clusters"]);
    } else {
      systemAudio.playError();
      setTestStage(`إعادة المحاولة (${attempt}/3)...`);
      addLog(`[RETRY] بدء محاولة التشخيص رقم ${attempt}...`);
    }
  };

  const runDiagnostic = () => {
    if (backoffTimeoutRef.current) {
      clearTimeout(backoffTimeoutRef.current);
    }
    startDiagnostic(0);
  };

  const exportData = () => {
    const data = {
      timestamp: new Date().toISOString(),
      systemStatus: isTesting ? 'testing' : 'idle',
      testStage,
      metrics,
      logs,
      insights
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `neuralis-export-${new Date().getTime()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    addLog("[SYS] تم إنشاء وتصدير ملف البيانات بنجاح.");
  };

  const runNeuralAnalysis = async (currentLogs: string[], currentMetrics: SystemMetrics) => {
    setIsAnalyzing(true);
    addLog("[AI] تنشيط المحرك العصبي لتوليد الرؤى...");
    try {
      const generatedInsights = await generateNeuralInsights(currentLogs, currentMetrics);
      
      if (!generatedInsights || generatedInsights.length === 0) {
          throw new Error("لا توجد رؤى تم توليدها");
      }

      setInsights(generatedInsights);
      addLog("[AI] اكتمل تحليل المحرك العصبي بنجاح.");
      
      // Select the first insight to speak aloud
      if (generatedInsights.length > 0) {
        setIsSpeaking(true);
        try {
          const textToSpeak = `اكتمل الفحص. أهم استنتاج: ${generatedInsights[0].title}. ${generatedInsights[0].desc}`;
          const audioBase64 = await generateSpeech(textToSpeak);
          if (audioBase64) {
            await systemAudio.playPCM(audioBase64);
          } else {
             addLog("[WARN] لم يتم استلام صوت من المولد العصبي.");
          }
        } catch (audioErr) {
          console.error("Speech Error:", audioErr);
          addLog("[ERROR] فشل نظام الانبعاث الصوتي في المعالجة.");
        } finally {
          setIsSpeaking(false);
        }
      }

    } catch (error) {
      console.error("Neural Analysis Error:", error);
      addLog("[ERROR] خطأ حرج: تعذر توليد الرؤى عبر المحرك العصبي. الخوادم لا ترد.");
      setInsights([{
        title: "فشل التحليل العصبي",
        desc: "لم نتمكن من الوصول لخدمات الذكاء الاصطناعي حالياً. يرجى مراجعة إعدادات الخادم ومفتاح API.",
        status: "critical"
      }]);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Real-time data stream for system metrics (Updates independently of diagnostic testing)
  useEffect(() => {
    const streamInterval = setInterval(() => {
      setMetrics(prev => {
        // Creates a smooth random walk for the metrics to feel like a live data stream
        const walk = () => (Math.random() - 0.5);
        return {
          cpu: Number(Math.min(100, Math.max(0, prev.cpu + walk() * 2.5)).toFixed(1)),
          patterns: Number(Math.min(100, Math.max(0, prev.patterns + walk() * 5)).toFixed(1)),
          data: Number(Math.max(0, prev.data + (walk() * 0.1)).toFixed(2))
        };
      });
    }, 600);
    
    return () => clearInterval(streamInterval);
  }, []);

  useEffect(() => {
    if (isTesting) {
      const interval = setInterval(() => {
        setTestProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsTesting(false);
            setTestStage("Diagnostic Complete");
            addLog("[DONE] System Analysis Finished.");
            setRetryCount(0);
            
            systemAudio.playSuccess();
            
            // Trigger AI insight generation
            runNeuralAnalysis(logs, metrics);
            
            return 100;
          }
          const next = prev + 1;
          
          // Simulate a diagnostic failure around 65% with a 40% probability
          if (next === 65 && Math.random() < 0.4) {
            clearInterval(interval);
            setIsTesting(false);
            systemAudio.playError();
            
            if (retryCount < 3) {
              addLog("[ERROR] انقطاع مفاجئ. الخوادم لا تستجيب.");
              const nextAttempt = retryCount + 1;
              const delaySeconds = Math.pow(2, nextAttempt); // Exponential backoff: 2s, 4s, 8s
              
              addLog(`[SYS] تمت جدولة المحاولة ${nextAttempt}/3 بعد ${delaySeconds} ثانية...`);
              
              backoffTimeoutRef.current = setTimeout(() => {
                startDiagnostic(nextAttempt);
              }, delaySeconds * 1000);
            } else {
              setTestStage("Failure");
              addLog("[CRITICAL] فشل الاختبار الشامل بعد 3 محاولات. يتطلب فحص يدوي.");
              setRetryCount(0);
            }
            return prev;
          }

          if (next % 10 === 0) {
            const messages = [
              `[SCAN] Cluster ${Math.floor(next/10)} verified`,
              `[DB] Indexing archive block ${next}00`,
              `[SEC] Key entropy validated at ${90 + Math.random()*10}%`,
              `[SYS] Optimizing pathway ${next}`
            ];
            addLog(messages[Math.floor(Math.random() * messages.length)]);
          }

          if (next === 10) setTestStage("Ping Echo Nodes...");
          if (next === 20) setTestStage("Scanning Neuralis Clusters...");
          if (next === 35) setTestStage("Verifying Cluster Integrity...");
          if (next === 50) setTestStage("Authenticating Archive Keys...");
          if (next === 65) setTestStage("Bypassing Neural Firewalls...");
          if (next === 80) setTestStage("Optimizing Data Paths...");
          if (next === 90) setTestStage("Finalizing Metric Assembly...");

          return next;
        });
      }, 50);
      
      return () => clearInterval(interval);
    }
  }, [isTesting, retryCount]);

  useEffect(() => {
    return () => {
      if (backoffTimeoutRef.current) {
        clearTimeout(backoffTimeoutRef.current);
      }
    };
  }, []);

  return (
    <div dir="rtl" className="flex flex-col h-screen bg-app-bg text-app-text font-sans selection:bg-app-gold selection:text-app-bg overflow-hidden">
      <Header isTesting={isTesting} isSpeaking={isSpeaking} onExport={exportData} />

      {/* Main Content */}
      <main 
        role="main"
        className="flex-1 grid grid-cols-1 md:grid-cols-[300px_1fr_260px] bg-app-border gap-px overflow-hidden"
      >
        {/* Left Column: Metrics */}
        <MetricsPanel metrics={metrics} isTesting={isTesting} />

        {/* Center Column: Visualizer */}
        <section 
          className="bg-app-bg relative flex flex-col items-center justify-center visualizer overflow-hidden"
          aria-label="منطقة التحليل البصري لحالة النظام"
        >
          <div className="grid-overlay absolute inset-0 opacity-30" aria-hidden="true" />
          
          <DiagnosticVisualizer 
            isTesting={isTesting}
            testProgress={testProgress}
            testStage={testStage}
            runDiagnostic={runDiagnostic}
          />

          <SystemLogs logs={logs} isTesting={isTesting} />
        </section>

        {/* Right Column: Insights */}
        <InsightsPanel 
          isTesting={isTesting} 
          isAnalyzing={isAnalyzing} 
          insights={insights} 
          onRefresh={() => runNeuralAnalysis(logs, metrics)}
        />
      </main>

      <Footer isTesting={isTesting} />

      {/* Floating Action Buttons */}
      <div className="fixed bottom-4 left-4 z-40 flex flex-col gap-3">
        <button 
          onClick={() => setIsSettingsOpen(true)}
          className="bg-app-border text-app-text-dim p-3 rounded-full hover:bg-black hover:text-white shadow-[0_0_15px_rgba(0,0,0,0.5)] transition-all flex items-center justify-center border border-app-border"
          aria-label="فتح إعدادات النظام"
          aria-expanded={isSettingsOpen}
          aria-controls="settings-dialog"
          title="System Settings"
        >
          <Settings2 className="w-5 h-5" aria-hidden="true" />
        </button>

        <button 
          onClick={() => setIsTerminalOpen(true)}
          className="bg-app-gold text-black p-3 rounded-full hover:bg-yellow-400 shadow-[0_0_15px_rgba(212,175,55,0.4)] transition-all flex items-center justify-center"
          aria-label="فتح محطة الأوامر العصبية"
          aria-expanded={isTerminalOpen}
          aria-controls="neural-terminal-dialog"
          title="Terminal Access"
        >
          <Terminal className="w-5 h-5" aria-hidden="true" />
        </button>
      </div>

      <AnimatePresence>
        {isTerminalOpen && (
          <NeuralTerminal 
            onClose={() => setIsTerminalOpen(false)} 
            onRunTest={runDiagnostic}
            onExport={exportData}
          />
        )}
        {isSettingsOpen && <SettingsModal onClose={() => setIsSettingsOpen(false)} />}
      </AnimatePresence>
    </div>
  );
}

