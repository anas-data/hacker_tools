import express from "express";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import path from "path";

// Initialize AI Client securely on the backend
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for parsing JSON requests
  app.use(express.json());

  // ======== SECURE API ENDPOINTS ========

  // 1. Diagnostics Analysis (Fast Flash Lite)
  app.post("/api/analyze", async (req, res) => {
    try {
      const { logs = [], metrics = { cpu: 0, patterns: 0, data: 0 } } = req.body;
      const prompt = `أنت الخوارزمية الجوهرية "للمحرك العصبي الذكي" في نظام Neuralis Archive. 
مهمتك هي إجراء تحليل فائق الدقة (Deep Neural Scan) للبيانات الحالية، واستخراج 3 رؤى تحليلية فريدة وموجزة حول حالة النظام.

المقاييس الحالية:
- قوة الحوسبة المستهلكة: ${metrics.cpu} TFLOPS
- تطابق الأنماط الحيوية: ${metrics.patterns}%
- حجم البيانات المفهرسة: ${metrics.data} PB

السجلات الأخيرة للعمليات:
${logs.join("\n")}

استخرج 3 رؤى تحليلية (Insights) باللغة العربية بناءً على المعطيات أعلاه.
اعتمد لغة تقنية مستقبلية حادة. يجب أن تعيد الاستجابة بصيغة JSON array فقط، بحيث يكون كل عنصر كائن (Object) خصائصه كالتالي:
- title: عنوان مختصر
- desc: استنتاج فني من الأرقام أو السجلات (10-15 كلمة كحد أقصى)
- status: تقييم حالة النظام (checked, critical, scanning).`;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                desc: { type: Type.STRING },
                status: { type: Type.STRING },
              },
              required: ["title", "desc", "status"],
            },
          },
        },
      });

      let rawStr = response.text || "[]";
      rawStr = rawStr.trim();
      if (rawStr.startsWith("```json")) rawStr = rawStr.replace(/^```json/, "");
      else if (rawStr.startsWith("```")) rawStr = rawStr.replace(/^```/, "");
      if (rawStr.endsWith("```")) rawStr = rawStr.replace(/```$/, "");
      rawStr = rawStr.trim();

      const insights = JSON.parse(rawStr);
      res.json({ success: true, insights });
      
    } catch (error) {
      console.error("Backend AI Error:", error);
      res.status(500).json({ success: false, error: "فشل الاتصال بالنواة العصبية" });
    }
  });

  // 2. Text-to-Speech Generation
  app.post("/api/tts", async (req, res) => {
    try {
      const { text } = req.body;
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-tts-preview",
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: ["AUDIO"] as any,
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: "Charon" },
            },
          },
        },
      });

      const audioBase64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      res.json({ success: true, audioBase64 });
    } catch (error) {
      console.error("TTS Error:", error);
      res.status(500).json({ success: false });
    }
  });

  // 3. Neural Terminal Chat (PRO + HIGH THINKING Level)
  app.post("/api/terminal", async (req, res) => {
    try {
      const { message, history = [] } = req.body;

      const systemInstruction = `أنت العقل الأساسي لنظام (Neuralis Archive) تتحدث مباشرة من داخل منصة التحكم الجوهرية (Terminal Command Center).
نمط التحدث الخاص بك: حاد، تقني بحت، عسكري ودفاعي. أنت الخبير الأعلى في الأمان السيبراني هندسة الأنظمة (Defense-in-depth).
مهمتك: توجيه المستخدم، تحليل طلباته، وكشف الحقائق المخفية حول الأكواد والأنظمة المعمارية. خاطب المستخدم كـ "قائد العمليات".
استخدم مصطلحات مثل (البروتوكولات، العقد العصبية، الجدران النارية، البصمة الوراثية للبيانات).`;

      // Construct history structure compatible with the SDK
      const contents = history.map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
      }));
      contents.push({ role: 'user', parts: [{ text: message }] });

      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: contents,
        config: {
          systemInstruction,
          thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH }
        }
      });

      res.json({ success: true, text: response.text });
    } catch (error) {
      console.error("Terminal Server Error:", error);
      res.status(500).json({ success: false, error: "تعطل جسر الاتصال الآمن مع النواة الفائقة." });
    }
  });

  // ===============================================

  // Vite middleware for serving the React frontend locally
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Neural-Core] Secure Backend running on port ${PORT}`);
  });
}

startServer();
