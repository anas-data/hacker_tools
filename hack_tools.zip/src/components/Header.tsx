import { motion } from "motion/react";
import { Download, Volume2 } from "lucide-react";

interface HeaderProps {
  isTesting: boolean;
  isSpeaking?: boolean;
  onExport?: () => void;
}

export function Header({ isTesting, isSpeaking, onExport }: HeaderProps) {
  return (
    <header className="relative h-20 border-b border-app-border flex items-center justify-between px-6 md:px-10 shrink-0 overflow-hidden">
      
      {/* Background Animated Waves - Visible only when NOT testing */}
      {!isTesting && (
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none" aria-hidden="true">
          {/* Dark Gray Wave */}
          <motion.div 
            className="absolute bottom-0 left-0 h-[70%] text-app-text-dim opacity-[0.03] w-[200vw] flex"
            animate={{ x: [0, "-50%"] }}
            transition={{ repeat: Infinity, duration: 25, ease: "linear" }}
            style={{ animationDuration: `calc(25s / var(--anim-speed, 1))` }}
          >
            <svg preserveAspectRatio="none" viewBox="0 0 1000 100" className="w-[100vw] h-full" fill="currentColor">
              <path d="M0,70 C150,40 350,10 500,50 C650,90 850,100 1000,70 L1000,100 L0,100 Z" />
            </svg>
            <svg preserveAspectRatio="none" viewBox="0 0 1000 100" className="w-[100vw] h-full" fill="currentColor">
              <path d="M0,70 C150,40 350,10 500,50 C650,90 850,100 1000,70 L1000,100 L0,100 Z" />
            </svg>
          </motion.div>
          {/* Gold Wave */}
          <motion.div 
            className="absolute bottom-0 left-0 h-[60%] text-app-gold opacity-[0.05] w-[200vw] flex"
            animate={{ x: [0, "-50%"] }}
            transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
            style={{ animationDuration: `calc(20s / var(--anim-speed, 1))` }}
          >
            <svg preserveAspectRatio="none" viewBox="0 0 1000 100" className="w-[100vw] h-full" fill="currentColor">
              <path d="M0,50 C150,0 350,100 500,50 C650,0 850,100 1000,50 L1000,100 L0,100 Z" />
            </svg>
            <svg preserveAspectRatio="none" viewBox="0 0 1000 100" className="w-[100vw] h-full" fill="currentColor">
              <path d="M0,50 C150,0 350,100 500,50 C650,0 850,100 1000,50 L1000,100 L0,100 Z" />
            </svg>
          </motion.div>
        </div>
      )}

      <h1 className="relative z-10 font-serif text-xl md:text-2xl tracking-tight text-app-gold italic">
        نظام التحليل الفائق — Neuralis Archive 01
      </h1>
      <div className="relative z-10 flex items-center gap-6">
        {/* Audio Indiciator */}
        {isSpeaking && (
          <div 
            className="flex items-center gap-2 text-app-gold text-[10px] uppercase tracking-widest"
            role="status"
            aria-live="polite"
          >
            <motion.div
              animate={{ opacity: [0.3, 1, 0.3], scale: [0.9, 1.1, 0.9] }}
              transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
            >
              <Volume2 className="w-4 h-4" aria-hidden="true" />
            </motion.div>
            <span className="hidden sm:inline">جاري البث العصبــي...</span>
          </div>
        )}

        <div 
          className="hidden sm:flex text-[11px] uppercase tracking-[2px] text-app-text-dim items-center gap-2.5"
          role="status"
          aria-live="polite"
        >
          <motion.div
            animate={{ opacity: isTesting ? [0.4, 1, 0.4] : 1 }}
            transition={isTesting ? { repeat: Infinity, duration: 1 } : {}}
            className={`w-1.5 h-1.5 rounded-full shadow-[0_0_10px_var(--color-app-gold)] ${isTesting ? 'bg-app-gold' : 'bg-green-500 shadow-green-500'}`}
            aria-hidden="true"
          />
          <span>{isTesting ? "جاري الاختبار..." : "النظام جاهز"}</span>
        </div>
        
        {onExport && (
          <button 
            onClick={onExport}
            className="flex items-center gap-2 px-3 py-1.5 border border-app-border hover:border-app-gold/50 rounded-sm text-[10px] text-app-text-dim hover:text-app-gold transition-colors"
            title="تصدير السجلات والمقاييس"
            aria-label="تصدير السجلات والمقاييس إلى ملف JSON"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            <span className="hidden md:inline uppercase tracking-wider">تصدير</span>
          </button>
        )}
      </div>
    </header>
  );
}
