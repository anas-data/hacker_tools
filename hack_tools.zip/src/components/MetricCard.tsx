import { motion } from "motion/react";
import { MetricCardProps } from "../types";

export function MetricCard({ label, value, progress, icon }: MetricCardProps) {
  return (
    <article className="metric-card" aria-label={`مقياس: ${label}`}>
      <div className="flex items-center justify-between mb-1.5" aria-hidden="true">
        <span className="text-[10px] text-app-text-dim uppercase tracking-wide flex items-center gap-2">
          {icon}
          {label}
        </span>
      </div>
      <div 
        className="text-[32px] font-serif font-light"
        aria-live="polite"
        aria-atomic="true"
        aria-label={`القيمة الحالية: ${value}`}
      >
        {value}
      </div>
      {progress !== undefined && (
        <div 
          className="w-full h-0.5 bg-app-border mt-2.5 overflow-hidden"
          role="progressbar"
          aria-valuenow={progress}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label={`تطور مقياس ${label}`}
        >
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${Math.min(100, progress)}%` }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="h-full bg-app-gold"
          />
        </div>
      )}
    </article>
  );
}
