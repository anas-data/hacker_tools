interface FooterProps {
  isTesting: boolean;
}

export function Footer({ isTesting }: FooterProps) {
  return (
    <footer 
      className="h-[50px] border-t border-app-border flex items-center justify-between px-6 md:px-10 text-[9px] text-app-text-dim bg-app-surface shrink-0"
      aria-label="معلومات النظام السفلية"
    >
      <div className="flex items-center gap-4" aria-live="polite">
        <span>ترميز النظام: v4.8.2-delta</span>
        <span className="hidden sm:block w-px h-3 bg-app-border" aria-hidden="true" />
        <span className={`${isTesting ? "text-app-gold" : ""} hidden sm:block`}>نواة العمليات: {isTesting ? "مشغولة" : "خاملة"}</span>
      </div>
      <div className="tracking-[1px] hidden lg:block">© 2024 مختبرات الذكاء الحاسوبي | جميع الحقوق محفوظة</div>
      <div aria-live="polite">آخر مزامنة: منذ {isTesting ? "0" : "12"} ثانية</div>
    </footer>
  );
}
