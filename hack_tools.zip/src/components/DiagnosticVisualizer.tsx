import { motion, AnimatePresence } from "motion/react";
import { Play, CheckCircle2, RotateCw } from "lucide-react";

interface DiagnosticVisualizerProps {
  isTesting: boolean;
  testProgress: number;
  testStage: string;
  runDiagnostic: () => void;
}

export function DiagnosticVisualizer({ isTesting, testProgress, testStage, runDiagnostic }: DiagnosticVisualizerProps) {
  const isSuccess = !isTesting && testProgress === 100;

  return (
    <div className="relative z-10 flex flex-col items-center w-full px-4 sm:px-12">
      <motion.div 
        role="progressbar"
        aria-valuenow={testProgress}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label="تقدم الفحص الشامل"
        animate={{ 
          scale: isTesting ? [1, 1.03, 1] : (isSuccess ? [1, 1.05, 1] : [1, 1.01, 1]),
          opacity: isTesting ? 1 : (isSuccess ? 1 : [0.7, 0.9, 0.7]),
          borderColor: isSuccess ? "rgba(34, 197, 94, 0.5)" : "var(--gold)",
          boxShadow: isTesting 
             ? ["0 0 20px rgba(197,160,89,0.2)", "0 0 40px rgba(197,160,89,0.5)", "0 0 20px rgba(197,160,89,0.2)"]
             : (isSuccess 
                 ? ["0 0 30px rgba(34,197,94,0.2)", "0 0 50px rgba(34,197,94,0.4)", "0 0 30px rgba(34,197,94,0.2)"] 
                 : ["0 0 10px rgba(197,160,89,0.05)", "0 0 20px rgba(197,160,89,0.15)", "0 0 10px rgba(197,160,89,0.05)"])
        }}
        transition={{ 
          repeat: Infinity, 
          duration: isTesting ? 1.5 : (isSuccess ? 3 : 4), 
          ease: "easeInOut" 
        }}
        style={{ animationDuration: `calc(1s / var(--anim-speed))` }}
        className="w-[280px] h-[280px] sm:w-[380px] sm:h-[380px] border rounded-full flex items-center justify-center relative transition-colors duration-1000 mb-8"
      >
        <motion.div 
          animate={{ rotate: isTesting ? 720 : 360 }}
          transition={{ repeat: Infinity, duration: isTesting ? 5 : 20, ease: "linear" }}
          className={`absolute inset-4 border border-dashed rounded-full transition-colors duration-1000 ${isSuccess ? "border-green-500/40" : "border-app-gold/40"}`}
        />
        
        {/* Inner subtle activity ring */}
        <motion.div
           animate={{ 
             scale: isTesting ? [1, 1.08, 1] : [1, 1.02, 1],
             opacity: isTesting ? [0.1, 0.2, 0.1] : (isSuccess ? [0.1, 0.2, 0.1] : [0.02, 0.08, 0.02])
           }}
           transition={{ repeat: Infinity, duration: isTesting ? 1 : 3, ease: "easeInOut" }}
           className={`absolute inset-8 border rounded-full transition-colors duration-1000 ${isSuccess ? "border-green-500 bg-green-500/10" : "border-app-gold bg-app-gold/10"}`}
        />

        <div className="text-center z-10 px-4">
          <AnimatePresence mode="wait">
            <motion.div 
              key={isTesting ? "testing" : (isSuccess ? "success" : "active")}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.2 }}
              className={`text-[10px] sm:text-[12px] tracking-[3px] uppercase mb-2 flex items-center justify-center gap-2 font-mono ${isSuccess ? "text-green-500" : "text-app-gold/80"}`}
            >
              {isSuccess && <CheckCircle2 className="w-4 h-4" />}
              <span>{isTesting ? "جاري المعالجة" : (isSuccess ? "نجاح الفحص" : "المحرك العصبي")}</span>
            </motion.div>
          </AnimatePresence>
          <motion.div 
            animate={{ opacity: isTesting || isSuccess ? 1 : [0.6, 1, 0.6] }}
            transition={{ duration: isTesting || isSuccess ? 0 : 3, repeat: Infinity, ease: "easeInOut" }}
            className={`text-4xl sm:text-5xl font-serif font-light flex items-center justify-center gap-2 ${isSuccess ? "text-green-400" : "text-app-gold"}`}
          >
            {isTesting || isSuccess ? `${testProgress}%` : "نشط"}
          </motion.div>
          
          {/* Diagnostic Stage Indicator Inside Circle */}
          <AnimatePresence mode="popLayout">
            {isTesting && testStage && (
              <motion.div
                key={testStage}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute left-0 right-0 top-3/4 flex justify-center text-[10px] text-app-text-muted font-mono px-4 text-center"
                aria-live="polite"
              >
                {testStage}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      {/* Diagnostic Button overlay */}
      {!isTesting && (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={runDiagnostic}
          className={`absolute bottom-0 left-1/2 -translate-x-1/2 flex items-center gap-2 px-6 py-2 border bg-app-bg/80 backdrop-blur-sm text-[10px] uppercase tracking-[2px] rounded-sm transition-all whitespace-nowrap z-20 ${
            isSuccess 
              ? "border-green-500/40 hover:border-green-500 text-green-500" 
              : "border-app-gold/30 hover:border-app-gold text-app-gold"
          }`}
        >
          {isSuccess ? <RotateCw className="w-3 h-3" /> : <Play className="w-3 h-3 fill-current" />}
          {isSuccess ? "إعادة الفحص" : "بدء الاختبار الشامل"}
        </motion.button>
      )}

      {/* Subtle Progress Bar */}
      <AnimatePresence>
        {isTesting && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute -bottom-8 left-4 right-4 sm:left-12 sm:right-12 h-[2px] bg-app-border/40 overflow-hidden rounded-full shadow-[0_0_10px_rgba(0,0,0,0.5)]"
            aria-hidden="true"
          >
            <motion.div 
              className="h-full bg-app-gold shadow-[0_0_8px_var(--gold)]"
              initial={{ width: "0%" }}
              animate={{ width: `${testProgress}%` }}
              transition={{ ease: "easeOut", duration: 0.3 }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
