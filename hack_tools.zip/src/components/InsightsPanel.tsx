import { Layers, Search, ShieldAlert, Cpu, Database, Activity, Code, Loader2 } from "lucide-react";
import { InsightItem } from "./InsightItem";
import { InsightData } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { useEffect, useRef } from "react";

interface InsightsPanelProps {
  isTesting: boolean;
  isAnalyzing: boolean;
  insights: InsightData[];
  onRefresh?: () => void;
}

export function InsightsPanel({ isTesting, isAnalyzing, insights, onRefresh }: InsightsPanelProps) {
  const onRefreshRef = useRef(onRefresh);

  // Keep the ref updated so the interval always uses the latest callback without restarting
  useEffect(() => {
    onRefreshRef.current = onRefresh;
  }, [onRefresh]);

  // Handle the automatic 30-second refresh
  useEffect(() => {
    if (!isTesting && !isAnalyzing) {
      const intervalId = setInterval(() => {
        if (onRefreshRef.current) {
          onRefreshRef.current();
        }
      }, 30000); // 30 seconds
      return () => clearInterval(intervalId);
    }
  }, [isTesting, isAnalyzing]);

  // Helper to pick a semantic icon based on status and title keywords
  const getIcon = (status: string, title: string) => {
    // 1. Mandatory status overrides
    if (status === "critical") return <ShieldAlert className="w-4 h-4 text-red-500" />;
    if (status === "scanning") return <Search className="w-4 h-4 text-app-gold" />;
    
    // 2. Deterministic semantic mapping based on Arabic title keywords
    const t = title.toLowerCase();
    
    if (t.includes("بيانات") || t.includes("تخزين") || t.includes("مفهرس") || t.includes("قاعدة") || t.includes("حجم")) {
      return <Database className="w-4 h-4" />;
    }
    
    if (t.includes("حوسبة") || t.includes("معالج") || t.includes("طاقة") || t.includes("نواة") || t.includes("استهلاك") || t.includes("أداء")) {
      return <Cpu className="w-4 h-4" />;
    }
    
    if (t.includes("مسار") || t.includes("هيكل") || t.includes("شبكة") || t.includes("تداخل") || t.includes("تزامن")) {
      return <Layers className="w-4 h-4" />;
    }
    
    if (t.includes("شفر") || t.includes("تشفير") || t.includes("أمان") || t.includes("خوارزمية") || t.includes("نظام")) {
      return <Code className="w-4 h-4" />;
    }
    
    // Default fallback
    return <Activity className="w-4 h-4" />;
  };

  return (
    <section 
      className="hidden md:flex bg-app-bg p-8 border-r border-app-border flex-col overflow-y-auto relative"
      aria-label="لوحة الرؤى والتحليلات"
    >
      <h2 id="insights-heading" className="font-serif text-lg font-normal border-b border-app-border pb-2.5 mb-6 flex justify-between items-center">
        <span>رؤى التحليل العصبي</span>
        {isAnalyzing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-2 text-xs text-app-gold"
            role="status"
            aria-live="polite"
          >
            <Loader2 className="w-3 h-3 animate-spin" aria-hidden="true" />
            يتم التوليد
          </motion.div>
        )}
      </h2>
      
      <div className="relative flex-1" aria-live="polite" aria-busy={isAnalyzing}>
        <AnimatePresence mode="popLayout">
          {isAnalyzing ? (
            <motion.div 
              key="loading-skeleton"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex flex-col gap-6 w-full"
              aria-hidden="true"
            >
              {[1, 2, 3].map((i) => (
                <div key={`skel-${i}`} className="pr-4 border-r-2 border-app-border/40 flex flex-col gap-2">
                  <div className="h-4 w-1/2 bg-app-border/50 rounded-sm animate-pulse" />
                  <div className="h-3 w-full bg-app-border/30 rounded-sm animate-pulse" />
                  <div className="h-3 w-3/4 bg-app-border/30 rounded-sm animate-pulse" />
                </div>
              ))}
            </motion.div>
          ) : (
            <motion.ul 
              key="insights-list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ staggerChildren: 0.1 }}
              className="flex flex-col gap-6"
            >
              {insights.map((insight, idx) => (
                <motion.div
                  key={`insight-${idx}-${insight.title}`}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                >
                  <InsightItem 
                    title={insight.title}
                    desc={insight.desc}
                    icon={getIcon(insight.status, insight.title)}
                    status={isTesting && insight.status === "checked" ? "scanning" : insight.status}
                  />
                </motion.div>
              ))}
            </motion.ul>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
