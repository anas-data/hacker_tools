import { ReactNode } from "react";

export interface SystemMetrics {
  cpu: number;
  patterns: number;
  data: number;
}

export interface MetricCardProps {
  label: string;
  value: string;
  progress?: number;
  icon?: ReactNode;
}

export interface InsightData {
  title: string;
  desc: string;
  status: "scanning" | "checked" | "critical";
}

export interface InsightItemProps extends InsightData {
  icon: ReactNode;
}


