import { Activity, Cpu, Zap, Database } from "lucide-react";
import { SystemMetrics } from "../types";
import { MetricCard } from "./MetricCard";

interface MetricsPanelProps {
  metrics: SystemMetrics;
  isTesting: boolean;
}

export function MetricsPanel({ metrics, isTesting }: MetricsPanelProps) {
  return (
    <section 
      className="bg-app-bg p-6 md:p-8 flex flex-col gap-8 md:gap-10 overflow-y-auto"
      aria-labelledby="metrics-heading"
    >
      <h2 id="metrics-heading" className="font-serif text-lg font-normal border-b border-app-border pb-2.5 flex items-center justify-between">
        المقاييس الحاسوبية
        <Activity className={`w-4 h-4 text-app-gold ${isTesting ? 'animate-pulse' : ''}`} aria-hidden="true" />
      </h2>
      
      <div className="flex flex-col gap-8" aria-live="polite" aria-atomic="true">
        <MetricCard 
          label="قوة الحوسبة المستهلكة" 
          value={`${metrics.cpu} TFLOPS`} 
          progress={metrics.cpu}
          icon={<Cpu className="w-4 h-4 text-app-gold" aria-hidden="true" />}
        />
        <MetricCard 
          label="تطابق الأنماط" 
          value={`${metrics.patterns}%`} 
          progress={metrics.patterns}
          icon={<Zap className="w-4 h-4 text-app-gold" aria-hidden="true" />}
        />
        <MetricCard 
          label="البيانات المفهرسة" 
          value={`${metrics.data} PB`} 
          progress={62}
          icon={<Database className="w-4 h-4 text-app-gold" aria-hidden="true" />}
        />
      </div>
    </section>
  );
}
