import { useState, useRef, useEffect, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Terminal, X, Send, Cpu } from "lucide-react";
import { sendTerminalMessage } from "../services/geminiService";

interface NeuralTerminalProps {
  onClose: () => void;
  onRunTest?: () => void;
  onExport?: () => void;
}

interface ChatMessage {
  id: string;
  role: "user" | "model" | "system";
  text: string;
}

export function NeuralTerminal({ onClose, onRunTest, onExport }: NeuralTerminalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "sys-0",
      role: "system",
      text: "[النظام]: محطة الأوامر العصبية جاهزة. التفكير فائق النطاق (HIGH_THINKING) مفعل.\nاكتب /help لرؤية الأوامر المحلية المتاحة، أو أدخل استفساراتك لمعمارية الذكاء الاصطناعي..."
    }
  ]);
  const [input, setInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isProcessing]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;

    const userText = input.trim();
    setInput("");
    
    // Command Parsing
    if (userText.startsWith("/")) {
      const args = userText.split(" ");
      const cmd = args[0].toLowerCase();
      
      setMessages(prev => [...prev, { id: `usr-${Date.now()}`, role: "user", text: userText }]);
      
      if (cmd === "/clear") {
        setMessages([{ id: `sys-${Date.now()}`, role: "system", text: "تم تفريغ المحطة العصبية." }]);
        return;
      } else if (cmd === "/test") {
        if (onRunTest) onRunTest();
        setMessages(prev => [...prev, { id: `sys-${Date.now()}`, role: "system", text: "[SYS] تم إرسال أمر تفعيل الاختبار الشامل للأنظمة المركزية..." }]);
        return;
      } else if (cmd === "/export") {
        if (onExport) onExport();
        setMessages(prev => [...prev, { id: `sys-${Date.now()}`, role: "system", text: "[SYS] جارٍ استخراج حزمة البيانات..." }]);
        return;
      } else if (cmd === "/help") {
        const helpText = `الأوامر المتاحة في النظام المحلي:
  /help   - يعرض قائمة الأوامر المتاحة.
  /clear  - مسح سجل المحطة.
  /test   - بدء الاختبار التشخيصي الشامل للأنظمة.
  /export - تصدير السجلات والمقاييس الحالية كملف JSON.

  ملاحظة: أي نصوص أخرى سيتم تمريرها مباشرة لمعالج الذكاء الاصطناعي (Gemini).`;
        setMessages(prev => [...prev, { id: `sys-${Date.now()}`, role: "system", text: helpText }]);
        return;
      } else {
        setMessages(prev => [...prev, { id: `sys-${Date.now()}`, role: "system", text: `[ERROR] الأمر غير معروف: ${cmd}. اكتب /help للقائمة.` }]);
        return;
      }
    }

    // AI Flow
    const newUserMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: "user",
      text: userText,
    };
    
    setMessages(prev => [...prev, newUserMsg]);
    setIsProcessing(true);

    // Pass only previous model/user messages to history
    const history = messages
      .filter(m => m.role !== "system") 
      .map(m => ({ role: m.role, text: m.text }));

    const reply = await sendTerminalMessage(userText, history as any);

    const newSystemMsg: ChatMessage = {
      id: `sys-${Date.now()}`,
      role: "model",
      text: reply,
    };

    setMessages(prev => [...prev, newSystemMsg]);
    setIsProcessing(false);
  };

  return (
    <motion.div 
      id="neural-terminal-dialog"
      role="dialog"
      aria-modal="true"
      aria-labelledby="terminal-title"
      initial={{ opacity: 0, scale: 0.95, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: 20 }}
      className="fixed inset-4 md:inset-20 z-50 rounded-xl overflow-hidden shadow-2xl flex flex-col border border-app-gold"
      style={{ backgroundColor: "rgba(10, 10, 10, 0.95)", backdropFilter: "blur(16px)" }}
    >
      {/* Header */}
      <div className="bg-black/50 border-b border-app-border p-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Terminal className="text-app-gold w-5 h-5" aria-hidden="true" />
          <h2 id="terminal-title" className="font-mono text-sm tracking-wider text-app-text-muted">
            <span className="text-app-gold font-bold">NEURAL</span>_TERMINAL_PRO_V3.1
          </h2>
        </div>
        <button 
          onClick={onClose} 
          className="text-app-text-muted hover:text-white transition-colors"
          aria-label="إغلاق محطة الأوامر العصبية"
        >
          <X className="w-5 h-5" aria-hidden="true" />
        </button>
      </div>

      {/* Terminal View */}
      <div 
        role="log" 
        aria-live="polite" 
        aria-atomic="false"
        className="flex-1 overflow-y-auto p-6 font-mono text-sm space-y-4"
      >
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              key={msg.id} 
              className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}
            >
              <div 
                className={`max-w-[85%] px-4 py-3 rounded-md whitespace-pre-wrap ${
                  msg.role === "user" 
                  ? "bg-app-card border border-app-border text-white text-right" 
                  : msg.role === "system"
                  ? "bg-app-border/30 border border-app-border/50 text-app-text-muted"
                  : "bg-transparent text-app-gold"
                }`}
                style={msg.role === "model" ? { textShadow: "0 0 10px rgba(212,175,55,0.4)" } : undefined}
                aria-label={msg.role === "user" ? "إدخال المستخدم" : "استجابة النظام"}
              >
                {msg.role === "model" ? "> " : ""}
                {msg.text}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {isProcessing && (
          <div className="flex items-center gap-3 text-app-gold font-mono animate-pulse" aria-label="جاري معالجة الأمر">
            <Cpu className="w-4 h-4 animate-spin" aria-hidden="true" />
            <span>[يتم فك تشفير البيانات ومعالجة الاستنتاجات عالية الدقة...]</span>
          </div>
        )}
        <div ref={endOfMessagesRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="p-4 bg-app-card border-t border-app-border flex gap-3">
        <div className="flex-1 relative">
          <label htmlFor="terminal-input" className="sr-only">سطر الأوامر</label>
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-app-gold font-mono" aria-hidden="true">{`>`}</span>
          <input 
            id="terminal-input"
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isProcessing}
            placeholder="أدخل الأمر..."
            className="w-full bg-black border border-app-border rounded p-3 pr-8 focus:border-app-gold focus:outline-none transition-colors text-white font-mono"
            dir="rtl"
          />
        </div>
        <button 
          type="submit" 
          disabled={isProcessing || !input.trim()}
          className="bg-app-gold text-black px-6 rounded font-bold hover:bg-yellow-400 disabled:opacity-50 transition-colors flex items-center justify-center"
          aria-label="إرسال الأمر"
        >
          <Send className="w-4 h-4" aria-hidden="true" />
        </button>
      </form>
    </motion.div>
  );
}
