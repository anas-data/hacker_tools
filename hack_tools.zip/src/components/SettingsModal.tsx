import { motion } from "motion/react";
import { X, Moon, Sun, Settings2 } from "lucide-react";
import { useState, useEffect } from "react";

interface SettingsModalProps {
  onClose: () => void;
}

export function SettingsModal({ onClose }: SettingsModalProps) {
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('theme') as 'dark' | 'light') || 'dark';
  });
  const [accentColor, setAccentColor] = useState<string>(() => {
    return localStorage.getItem('accentColor') || '#C5A059';
  });
  const [animSpeed, setAnimSpeed] = useState<number>(() => {
    const saved = localStorage.getItem('animSpeed');
    return saved ? parseFloat(saved) : 1;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'light') {
      root.classList.add('light-theme');
    } else {
      root.classList.remove('light-theme');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Initial load effect for color and speed
  useEffect(() => {
    document.documentElement.style.setProperty('--gold', accentColor);
    document.documentElement.style.setProperty('--anim-speed', animSpeed.toString());
  }, []); // Run only once on mount to set initial styles

  const handleGoldChange = (val: string) => {
    setAccentColor(val);
    document.documentElement.style.setProperty('--gold', val);
    localStorage.setItem('accentColor', val);
  };

  const handleSpeedChange = (val: string) => {
    const speed = parseFloat(val);
    setAnimSpeed(speed);
    document.documentElement.style.setProperty('--anim-speed', speed.toString());
    localStorage.setItem('animSpeed', speed.toString());
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-title"
    >
      <motion.div 
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 20 }}
        className="w-full max-w-sm bg-app-surface border border-app-border rounded-lg shadow-2xl p-6 relative overflow-hidden"
      >
        <button 
          onClick={onClose} 
          className="absolute top-4 left-4 text-app-text-dim hover:text-white transition-colors"
          aria-label="إغلاق الإعدادات"
        >
          <X className="w-5 h-5" aria-hidden="true" />
        </button>
        
        <h2 id="settings-title" className="text-xl font-serif text-app-gold flex items-center gap-2 mb-6">
          <Settings2 className="w-5 h-5" aria-hidden="true" />
          إعدادات النظام
        </h2>
        
        <div className="space-y-6">
          <div className="space-y-3">
            <label className="text-sm text-app-text-dim block">المظهر (Theme)</label>
            <div className="flex gap-2">
              <button 
                onClick={() => setTheme('dark')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md border transition-colors ${theme === 'dark' ? 'bg-app-border border-app-gold text-app-text' : 'border-app-border text-app-text-dim hover:text-app-text'}`}
                aria-pressed={theme === 'dark'}
              >
                <Moon className="w-4 h-4" /> داكن
              </button>
              <button 
                onClick={() => setTheme('light')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md border transition-colors ${theme === 'light' ? 'bg-app-border border-app-gold text-app-text' : 'border-app-border text-app-text-dim hover:text-app-text'}`}
                aria-pressed={theme === 'light'}
              >
                <Sun className="w-4 h-4" /> فاتح
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center text-sm">
              <label htmlFor="accent-color" className="text-app-text-dim">درجة لون الهوية (Accent)</label>
              <span className="font-mono text-app-gold uppercase">{accentColor}</span>
            </div>
            <div className="flex gap-3 items-center">
              <input 
                id="accent-color"
                type="color"
                value={accentColor}
                onChange={(e) => handleGoldChange(e.target.value)}
                className="w-10 h-10 rounded cursor-pointer border-0 p-0 bg-transparent"
              />
              <div 
                className="text-xs text-app-text-dim flex-1 px-3 py-2 border border-app-border rounded-md bg-app-bg"
                aria-hidden="true"
              >
                انقر لاختيار درجة لونية مخصصة
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center text-sm">
              <label htmlFor="anim-speed" className="text-app-text-dim">سرعة الرسوم المتحركة</label>
              <span className="font-mono text-app-gold">{animSpeed}x</span>
            </div>
            <input 
              id="anim-speed"
              type="range"
              min="0.5"
              max="3"
              step="0.1"
              value={animSpeed}
              onChange={(e) => handleSpeedChange(e.target.value)}
              className="w-full accent-app-gold"
            />
          </div>
        </div>

      </motion.div>
    </motion.div>
  );
}
