import { motion, AnimatePresence } from "motion/react";
import { Activity, ShieldAlert } from "lucide-react";

interface SystemLogsProps {
  logs: string[];
  isTesting: boolean;
}

export function SystemLogs({ logs, isTesting }: SystemLogsProps) {
  return (
    <div 
      className="absolute inset-x-6 bottom-6 flex flex-col items-center gap-4"
      aria-label="سجلات وحالة النظام"
    >
      <div 
        role="log" 
        aria-live="polite" 
        aria-atomic="false"
        className="w-full max-w-lg bg-black/40 border border-app-border p-3 rounded-sm font-mono text-[9px] text-app-text-dim flex flex-col gap-1 min-h-[80px]"
      >
        <div className="flex items-center gap-2 border-b border-app-border/30 pb-1 mb-1">
          <div className="w-2 h-2 rounded-full bg-app-gold animate-pulse" aria-hidden="true" />
          <span className="text-app-gold uppercase tracking-tighter">سجل العمليات المباشر</span>
        </div>
        <AnimatePresence>
          {logs.map((log, i) => (
            <motion.div
              key={`${log}-${i}`}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className={`${i === 0 ? 'text-app-gold/70' : ''}`}
            >
              {log}
            </motion.div>
          ))}
        </AnimatePresence>
        {logs.length === 0 && <div className="italic text-app-text-dim/30">في انتظار التعليمات...</div>}
      </div>
      
      <div className="flex gap-6 text-app-text-dim text-[10px] uppercase tracking-wider" aria-live="polite">
        <div className="flex items-center gap-2" title={`النبض: ${isTesting ? "متسارع" : "مستقر"}`}>
          <Activity className="w-3 h-3 text-app-gold" aria-hidden="true" />
          النبض: {isTesting ? "متسارع" : "مستقر"}
        </div>
        <div className="flex items-center gap-2" title="الأمن: مشفر">
          <ShieldAlert className="w-3 h-3 text-app-gold" aria-hidden="true" />
          الأمن: مشفر
        </div>
      </div>
    </div>
  );
}
